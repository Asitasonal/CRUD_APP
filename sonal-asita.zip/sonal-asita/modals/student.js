const mongoose = require('mongoose');

const studentSchema = new mongoose.Schema({
    name: String,
    rollNo: String,
    degree: String,
    college: String,
    city: String
});

// Custom method for updating a student
studentSchema.methods.updateStudent = async function (updateData) {
    Object.assign(this, updateData);
    await this.save();
};

// Custom method for deleting a student
studentSchema.methods.deleteStudent = async function () {
    await this.deleteOne();
};

module.exports = mongoose.model('Student', studentSchema);

