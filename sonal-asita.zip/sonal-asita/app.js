const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const Student = require('./modals/student');

const app = express();

app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({ extended: true }));

// GET all students
app.get("/", async (req, res) => {
    try {
        const students = await Student.find();
        res.render('index', { students: students });
    } catch (error) {
        console.error('Error fetching students:', error);
        res.status(500).send('Error fetching students');
    }
});

// POST create a new student
app.post('/save', async (req, res) => {
    try {
        const { name, rollNo, degree, college, city } = req.body;
        const newStudent = new Student({ name, rollNo, degree, college, city });
        await newStudent.save();
        console.log('Student saved successfully');
        res.redirect('/');
    } catch (error) {
        console.error('Error saving student:', error);
        res.status(500).send('Error saving student');
    }
});

// PUT update a student
app.put('/update/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const { name, rollNo, degree, college, city } = req.body;
        const updatedStudent = await Student.findByIdAndUpdate(id, { name, rollNo, degree, college, city }, { new: true });
        console.log('Student updated successfully:', updatedStudent);
        res.send(updatedStudent);
    } catch (error) {
        console.error('Error updating student:', error);
        res.status(500).send('Error updating student');
    }
});

// DELETE delete a student
app.delete('/delete/:id', async (req, res) => {
    try {
        const { id } = req.params;
        await Student.findByIdAndDelete(id);
        console.log('Student deleted successfully');
        res.send('Student deleted successfully');
    } catch (error) {
        console.error('Error deleting student:', error);
        res.status(500).send('Error deleting student');
    }
});

const PORT = 3000;

mongoose.connect('mongodb://localhost:27017/StudentDB', {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
.then(() => {
    app.listen(PORT, () => {
        console.log(`Server is running on port ${PORT}`);
    });
})
.catch((error) => {
    console.error('Error connecting to MongoDB:', error);
});
